# Yahoo Finance Stock Market Data Pipeline

A production-grade data engineering pipeline that extracts stock market data from Yahoo Finance API, processes it using Apache Spark, stores it in a data warehouse, and visualizes insights using Metabase.

![Pipeline Architecture](pipeline_architecture.png)

## 📊 Project Overview

This project implements a complete ELT (Extract, Load, Transform) pipeline that:
- Fetches daily stock prices from Yahoo Finance API
- Stores raw data in MinIO (S3-compatible object storage)
- Transforms data using Apache Spark in Docker containers
- Loads processed data into PostgreSQL data warehouse
- Visualizes metrics in Metabase dashboards

### Tech Stack

- **Orchestration**: Apache Airflow (Astronomer Runtime 12.9.0)
- **Data Processing**: Apache Spark 3.3.0 with Hadoop 3.3
- **Object Storage**: MinIO (S3-compatible)
- **Data Warehouse**: PostgreSQL
- **Visualization**: Metabase
- **Containerization**: Docker & Docker Compose
- **Python Libraries**: Astro SDK, requests, minio-py

## 🏗️ Architecture

```
Yahoo Finance API
      ↓
┌─────────────────────────────────────────────────┐
│          Apache Airflow Orchestration           │
├─────────────────────────────────────────────────┤
│ 1. API Sensor (Health Check)                    │
│ 2. Extract Stock Prices (Python)                │
│ 3. Store Raw JSON (MinIO)                       │
│ 4. Transform Data (Spark in Docker)             │
│ 5. Load to Data Warehouse (PostgreSQL)          │
└─────────────────────────────────────────────────┘
      ↓
┌─────────────────────────────────────────────────┐
│            Data Flow & Storage                  │
├─────────────────────────────────────────────────┤
│ MinIO Bucket: stock-market/NVDA/                │
│   ├── prices.json (raw)                         │
│   └── formatted_prices/ (CSV)                   │
│                                                  │
│ PostgreSQL: public.stock_market                 │
│   └── Columns: date, open, high, low,           │
│                close, volume                     │
└─────────────────────────────────────────────────┘
      ↓
  Metabase Dashboard
```

## 🚀 Getting Started

### Prerequisites

- Docker Desktop (minimum 8GB RAM allocated)
- Astro CLI
- Python 3.9+
- Yahoo Finance API credentials

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/Aniruthan-0709/yahoo-finance-airflow-metabase-pipeline.git
cd yahoo-finance-airflow-metabase-pipeline
```

2. **Set up Airflow connections**

Create the following connections in Airflow UI (`Admin > Connections`):

**Stock API Connection** (`stock_api`):
- Connection Type: HTTP
- Host: `https://query1.finance.yahoo.com`
- Extra:
```json
{
  "endpoint": "/v8/finance/chart/",
  "headers": {
    "User-Agent": "Mozilla/5.0"
  }
}
```

**MinIO Connection** (`minio`):
- Connection Type: AWS
- Login: `minio`
- Password: `minio123`
- Host: `http://host.docker.internal:9000`
- Extra:
```json
{
  "endpoint_url": "http://host.docker.internal:9000"
}
```

**PostgreSQL Connection** (`postgres`):
- Connection Type: Postgres
- Host: `postgres`
- Schema: `public`
- Login: `postgres`
- Password: `postgres`
- Port: `5432`

3. **Build Docker images**
```bash
# Build Spark images
docker build -t airflow/spark-master ./spark/master
docker build -t airflow/spark-worker ./spark/worker

# Build stock transformation app
docker build -t airflow/stock-app -f Dockerfile .
```

4. **Start the environment**
```bash
astro dev start
```

This will start:
- Airflow webserver: http://localhost:8080
- MinIO console: http://localhost:9001
- Spark Master UI: http://localhost:8082
- Metabase: http://localhost:3000

## 📁 Project Structure

```
.
├── dags/
│   └── stock_market.py              # Main DAG definition
├── include/
│   ├── stock_market/
│   │   └── tasks.py                 # Task implementations
│   └── data/
│       ├── minio/                   # MinIO data volume
│       └── metabase/                # Metabase data volume
├── spark/
│   ├── master/                      # Spark master Dockerfile
│   ├── worker/                      # Spark worker Dockerfile
│   └── app/
│       └── stock_transform.py       # Spark transformation script
├── Dockerfile                       # Stock app Docker image
├── docker-compose.override.yaml     # Additional services
├── requirements.txt                 # Python dependencies
└── README.md
```

## 🔄 Pipeline Details

### DAG: `stock_market`

**Schedule**: Daily (`@daily`)  
**Start Date**: 2023-01-01  
**Catchup**: False  
**Default Symbol**: NVDA (configurable)

### Tasks

1. **is_api_available** (Sensor)
   - Polls Yahoo Finance API every 30 seconds
   - Timeout: 5 minutes
   - Returns API URL via XCom

2. **get_stock_prices** (PythonOperator)
   - Fetches 1 year of daily stock data
   - Metrics: OHLCV (Open, High, Low, Close, Volume)
   - Returns JSON response

3. **store_prices** (PythonOperator)
   - Creates MinIO bucket if not exists
   - Stores raw JSON: `stock-market/{SYMBOL}/prices.json`
   - Returns bucket path

4. **format_prices** (DockerOperator)
   - Runs Spark job in isolated container
   - Reads JSON from MinIO
   - Transforms nested structure to flat CSV
   - Writes back to MinIO: `stock-market/{SYMBOL}/formatted_prices/`

5. **get_formatted_csv** (PythonOperator)
   - Locates CSV file in MinIO bucket
   - Returns CSV path for loading

6. **load_to_dw** (Astro SDK)
   - Loads CSV from MinIO to PostgreSQL
   - Table: `public.stock_market`
   - Uses credentials from Airflow connections

## 🔧 Configuration

### Changing Stock Symbol

Edit `SYMBOL` variable in `dags/stock_market.py`:
```python
SYMBOL = 'AAPL'  # Change to any valid ticker
```

### Spark Memory Configuration

Modify `spark/master/spark-defaults.conf` or `spark/worker/spark-defaults.conf`:
```conf
spark.executor.memory=2g
spark.driver.memory=1g
```

### MinIO Bucket Name

Edit `BUCKET_NAME` in `include/stock_market/tasks.py`:
```python
BUCKET_NAME = 'your-bucket-name'
```

## 📊 Metabase Dashboard

Access Metabase at http://localhost:3000

**Setup Steps**:
1. Create account on first login
2. Connect to PostgreSQL database
3. Create new dashboard
4. Add visualizations:
   - Average Closing Price (Metric)
   - Average Volume (Metric)
   - Time Series: Close Price + Volume

**Sample Metrics** (NVDA, 2025):
- Average Closing Price: $144.43
- Average Volume: 225.3M shares

## 🐛 Troubleshooting

### Spark Job Hangs

**Symptoms**:
- Task stuck after "Passing arguments..."
- Task stuck after "Successfully stopped SparkContext"
- Warning: "Initial job has not accepted any resources"

**Solution**:
```bash
astro dev kill
astro dev start
```

Ensure Docker Desktop has at least **8GB RAM** allocated:
- Docker Desktop → Preferences → Resources → Advanced → Memory

### MinIO Connection Issues

**Error**: `S3Exception: Connection refused`

**Solution**:
- Check MinIO is running: `docker ps | grep minio`
- Verify endpoint in Airflow connection uses `host.docker.internal:9000`
- Test MinIO console: http://localhost:9001

### Docker Operator Failures

**Error**: `Cannot connect to Docker daemon`

**Solution**:
- Ensure `docker-proxy` service is running
- Check Docker socket mount in `docker-compose.override.yaml`
- Restart Docker Desktop

### CSV File Not Found

**Error**: `AirflowNotFoundException: The csv file does not exist`

**Solution**:
- Check Spark job completed successfully in Airflow logs
- Verify CSV exists in MinIO: http://localhost:9001
- Ensure correct bucket and prefix path in `_get_formatted_csv`

## 🔐 Security Notes

**Important**: This setup is for development/testing only.

For production:
- Use AWS Secrets Manager or HashiCorp Vault for credentials
- Enable SSL/TLS for MinIO
- Implement proper IAM roles and policies
- Use strong passwords (current defaults: minio/minio123)
- Enable Airflow RBAC
- Secure Metabase with proper authentication

## 📈 Performance Optimization

### Spark Tuning
```python
spark = SparkSession.builder \
    .config("spark.sql.shuffle.partitions", "10") \
    .config("spark.default.parallelism", "8") \
    .getOrCreate()
```

### MinIO Best Practices
- Use partitioned storage: `YYYY/MM/DD/`
- Enable versioning for data recovery
- Implement lifecycle policies for old data

### PostgreSQL Indexing
```sql
CREATE INDEX idx_stock_date ON stock_market(date);
CREATE INDEX idx_stock_symbol ON stock_market(symbol);
```

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [Apache Airflow](https://airflow.apache.org/)
- [Astronomer](https://www.astronomer.io/)
- [Yahoo Finance API](https://finance.yahoo.com/)
- [MinIO](https://min.io/)
- [Metabase](https://www.metabase.com/)
- [Apache Spark](https://spark.apache.org/)

## 📧 Contact

Aniruthan - [GitHub](https://github.com/Aniruthan-0709)

Project Link: [https://github.com/Aniruthan-0709/yahoo-finance-airflow-metabase-pipeline](https://github.com/Aniruthan-0709/yahoo-finance-airflow-metabase-pipeline)

---

**Built with ❤️ using modern data engineering practices**
from airflow.decorators import dag, task
from datetime import datetime
import random

@dag(
    dag_id='taskflow',
    start_date=datetime(2025, 1, 1),
    catchup=False,
    schedule='@daily',
    tags=['task_flow']
)
def task_flow():

    @task
    def generate_random_number():
        # Generate a random number between 1 and 100
        number = random.randint(1, 100)
        return number  # This return value is automatically pushed to XCom

    @task
    def check_even_odd(number):
        if number % 2 == 0:
            print(f"{number} is even")
        else:
            print(f"{number} is odd")

    # Task dependencies using TaskFlow API
    check_even_odd(generate_random_number())

# Instantiate the DAG
task_flow()
